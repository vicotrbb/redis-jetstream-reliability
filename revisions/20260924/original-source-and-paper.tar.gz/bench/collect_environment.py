"""Read only experiment pods, with an explicit homelab context on every call."""
import datetime
import json
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/environment"
K = ["kubectl", "--context", "homelab", "-n", "msgrel-20260923"]
PROFILES = [f"{e}-{m}" for e in ("redis", "nats") for m in ("memory", "periodic", "always")]

def get(*args):
    p = subprocess.run(K + list(args), text=True, capture_output=True, timeout=20)
    return {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}

if __name__ == "__main__":
    for p in PROFILES:
        if p.startswith("redis"):
            result = get("exec", p, "--", "redis-cli", "CONFIG", "GET", "append*", "save", "no-appendfsync-on-rewrite", "auto-aof-rewrite-percentage", "maxmemory", "maxmemory-policy")
        else:
            result = get("exec", p, "--", "cat", "/config/server.conf")
        (OUT / (p + "-effective-config.json")).write_text(json.dumps(result, indent=2) + "\n")
        (OUT / (p + "-startup-log.json")).write_text(json.dumps(get("logs", p), indent=2) + "\n")
    with (OUT / "telemetry.jsonl").open("a") as f:
        while True:
            result = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "top": get("top", "pods")}
            result["cgroup"] = {p: get("exec", p, "--", "cat", "/sys/fs/cgroup/cpu.stat") for p in PROFILES + ["runner"]}
            result["pods"] = get("get", "pods", "-o", "custom-columns=NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount")
            f.write(json.dumps(result) + "\n")
            f.flush()
            time.sleep(30)
