"""Explicit homelab-only deployment, execution, collection, and bounded cleanup."""
import argparse
import json
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
NS="msgrel-20260923"
K=["kubectl","--context","homelab"]

def run(*args, **kw):
    return subprocess.run(K+list(args),check=True,**kw)

def collect():
    (ROOT/"data/raw").mkdir(exist_ok=True)
    run("cp",f"{NS}/runner:/work/results/.",str(ROOT/"data/raw"))
    for name in ("pilot.log","pilot-final.log","main.log","main-resume.log","main-v3.log","durability.log","durability-resume.log","serial.log","recovery.log"):
        p=subprocess.run(K+["exec","-n",NS,"runner","--","cat",f"/work/{name}"],capture_output=True)
        if p.returncode==0:(ROOT/"data/environment"/name).write_bytes(p.stdout)
    for name in ("go.mod","go.sum"):
        run("cp",f"{NS}/runner:/work/{name}",str(ROOT/"bench"/name))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=["run","collect","cleanup"])
    a=p.parse_args()
    if a.action=="cleanup":
        run("delete","namespace",NS,"--wait=false")
        return
    if a.action=="collect":
        collect();return
    subprocess.run(["python3",str(ROOT/"k8s/generate.py")],check=True)
    run("apply","-f",str(ROOT/"k8s/experiment.json"))
    run("wait","-n",NS,"--for=condition=Ready","pod","--all","--timeout=180s")
    run("cp",str(ROOT/"bench")+"/.",f"{NS}/runner:/work/")
    command="cd /work && go build -o bench . && GOMAXPROCS=2 ./bench pilot /work/results/pilot-final > /work/pilot-final.log 2>&1 && GOMAXPROCS=2 ./bench main /work/results/main > /work/main.log 2>&1 && GOMAXPROCS=2 ./bench durability /work/results/durability > /work/durability.log 2>&1 && GOMAXPROCS=2 ./bench serial /work/results/serial > /work/serial.log 2>&1 && GOMAXPROCS=2 ./bench recovery /work/results/recovery > /work/recovery.log 2>&1"
    try:run("exec","-n",NS,"runner","--","sh","-c",command)
    finally:collect()

if __name__=="__main__":main()
