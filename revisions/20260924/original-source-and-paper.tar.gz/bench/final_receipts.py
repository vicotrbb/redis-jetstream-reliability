"""Capture final experiment-only state before removing the homelab namespace."""
import datetime
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/environment"
K = ["kubectl", "--context", "homelab", "-n", "msgrel-20260923"]
NAMES = [f"{e}-{m}" for e in ("redis", "nats") for m in ("memory", "periodic", "always")] + ["runner"]


def call(*args):
    p = subprocess.run(K + list(args), capture_output=True, text=True, timeout=60)
    return {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


if __name__ == "__main__":
    final = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "context": "homelab", "namespace": "msgrel-20260923", "pods": {}}
    for name in NAMES:
        pod = call("get", "pod", name, "-o", "json")
        if pod["returncode"]:
            final["pods"][name] = {"error": pod}
            continue
        raw = json.loads(pod["stdout"])
        final["pods"][name] = {
            "node": raw["spec"]["nodeName"],
            "phase": raw["status"]["phase"],
            "containers": [{"name": c["name"], "imageID": c.get("imageID"), "restartCount": c["restartCount"], "ready": c["ready"]} for c in raw["status"]["containerStatuses"]],
            "memory_events": call("exec", name, "--", "cat", "/sys/fs/cgroup/memory.events"),
            "cpu_stat": call("exec", name, "--", "cat", "/sys/fs/cgroup/cpu.stat"),
        }
        mounts = call("exec", name, "--", "cat", "/proc/mounts")
        final["pods"][name]["data_mount"] = {
            "returncode": mounts["returncode"],
            "lines": [line for line in mounts["stdout"].splitlines() if line.split()[1] in ("/data", "/work")],
            "stderr": mounts["stderr"],
        }
        if name != "runner":
            (OUT / f"{name}-final-log.json").write_text(json.dumps(call("logs", name), indent=2) + "\n")
        if name.startswith("redis"):
            final["pods"][name]["persistence"] = call("exec", name, "--", "redis-cli", "INFO", "persistence")
    final["driver_build"] = call("exec", "runner", "--", "go", "version", "-m", "/work/bench")
    final["driver_source_hashes"] = call("exec", "runner", "--", "sha256sum", "/work/main.go", "/work/durability.go", "/work/go.mod", "/work/go.sum", "/work/bench")
    (OUT / "final-state.json").write_text(json.dumps(final, indent=2) + "\n")
    errors = [name for name, p in final["pods"].items() if "error" in p]
    print(json.dumps({"utc": final["utc"], "pods_captured": len(final["pods"]), "read_errors": errors}))
