# An Empirical Evaluation of Message Delivery Reliability and Recovery Characteristics in Redis Streams and NATS JetStream

This folder contains the manuscript, experiment implementation, raw homelab evidence, deterministic statistical analysis, and generated figures. The article follows the LaTeX typography of `bfs-avoidance-frontier`: an 11-point single-column article, 1.1-inch margins, the same author block, numbered mathematical results, and a linked bibliography.

## Read the paper

- `output/pdf/redis-jetstream-reliability.pdf`: final reader-facing PDF.
- `paper/main.tex`: editable source; `abstract.tex`, `results.tex`, and `conclusion.tex` contain the corresponding prose.
- `data/derived/statistics.json`: numerical results and integrity receipts.
- `data/derived/aggregate.csv`: machine-readable estimates and confidence intervals.
- `formal/DeliveryModel.lean` and `formal/verification.json`: ten conditional model declarations checked with Lean 4.24.0 on the homelab.
- `docs/PRIMARY_SOURCES.md`: verified official documentation, pinned source-code references, and literature boundaries.
- `docs/MANUSCRIPT_REVIEW.md`: internal AI-assisted methods/proof/source review, not external peer review.

## Experimental scope

The only broker/test environment is `kubectl --context homelab`, namespace `msgrel-20260923`. The workstation performs authoring, raw-data verification, statistical analysis, and LaTeX compilation only.

Redis 7.4.2 and NATS Server 2.10.24, one replica each, run on `homelab-01`. The Go 1.24.4 driver runs on `homelab-02`. The broker volume is Btrfs/NVMe with `compress=zstd:3`; payloads contain an eight-byte ID and repeated `x` bytes, so they are highly compressible. Six persistence profiles, one shared consumer group/durable consumer, 512-byte application payloads, explicit confirmed acknowledgment, and independent TCP connections are used.

- RQ1: 120 consumer SIGKILL/recovery trials plus 10 Redis no-reclaimer controls. Timeout 250/1000 ms, kill age 10%/75%, Redis reclaim sleeps 10/100 ms.
- RQ2: 300 completed fixed-backlog trials, 16384 messages each, C=1/2/4/8/16, ten randomized complete blocks.
- RQ3: 60 planned five-second closed-loop publication trials, 16 outstanding publishers (one retained Redis-always timeout and 59 completed planned trials); a separate 60-trial one-publisher sensitivity uses 1024 messages.
- Two 12-trial pilot datasets are excluded from the reported main estimates.

The fixed-backlog and closed-loop latencies are not open-loop production SLA estimates. Consumer death is not a power-loss test. Model theorems are conditional mathematical results, not formal verification of the vendor implementations or a universal empirical ranking. All runtime incidents and protocol changes are retained in `docs/DEVIATIONS.md` and `data/environment/`.

## Delivered validation

All 550 planned experimental outcomes are accounted for: 300 completed drain trials, 59 completed primary publication trials plus one retained timeout, 60 completed serial trials, 120 recovered consumer kills, and ten censored negative controls. Raw timings and adjudication records remain available. The analyzer and final paper checks passed; ten selected conditional model declarations passed Lean on the homelab. See `docs/EXECUTION_RECEIPT.md` for validation and cleanup receipts.

The temporary namespace was removed after data and proof collection. `data/environment/cleanup.json` records the successful delete and the subsequent Kubernetes `NotFound` confirmation. Reanalysis requires no live broker.

## Reanalyze the existing measurements

The pinned analysis dependencies are in `requirements-analysis.txt`. For example:

```sh
uv venv .venv
uv pip install --python .venv/bin/python -r requirements-analysis.txt
make analyze
make paper
make verify
make checksums
```

Python 3.13 was used for analysis. LaTeX requires `latexmk`, pdfLaTeX, BibTeX, the packages declared in `paper/main.tex`, and `plainurl.bst`. `make verify` checks existing data and the compiled paper; it does not start a broker or execute a performance experiment on the workstation.

`bench/analyze.py` verifies every retained main/durability/serial raw CSV against its summary: IDs, ordering, percentiles, means, throughput, worker counts, and finite-window occupancy bounds. It reconstructs recovery intervals from the recorded monotonic timestamps. It then generates tables, figures, 10000-resample bootstrap intervals, and paired block ratios. Publication metrics condition on completed planned trials; the failed D038 outcome is retained in a separate adjudication ledger, its accidental replay is excluded, and comparisons use common completed blocks. No failure is assigned a made-up throughput or latency. A p99 interval describes uncertainty in the mean of run-level p99 values, not a pooled-message percentile or a distribution-free prediction interval.

## Run new experiments, only in the homelab

The namespace is dedicated to this artifact. Do not reuse it while another copy of the campaign is active. Do not substitute a production context. No other namespace, host configuration, storage class, node taint, or existing application is modified by these scripts.

```sh
make experiment
make collect
```

The runner compiles and executes the Go program inside the homelab, with modules locked by `bench/go.mod` and `bench/go.sum`. `k8s/experiment.json` is generated from `k8s/generate.py`. Exact image digests of the recorded campaign are in `data/environment/images.json`; the manifest generator uses `k8s/image-pins.json` when present. There is no workstation-hosted benchmark path.

The main, serial, and durability campaigns append to their JSONL checkpoint and skip successful scheduled conditions on resume. An error stops the collection for inspection; it does not silently replace that measurement. Pilot and recovery series should use fresh output directories if repeated. Durability continuation skips completed conditions and reruns the next excluded warm-up; its original interrupted log is retained separately. A new campaign should also use fresh pods/storage. Administrative requests have a 30-second budget; measured publisher/consumer requests retain their five-second budget. Read `docs/DEVIATIONS.md` before comparing harness revisions.

To inspect results while the process is running:

```sh
kubectl --context homelab exec -n msgrel-20260923 runner -- tail -1 /work/main.log
kubectl --context homelab top pods -n msgrel-20260923
```

Once raw data have been collected and verified, remove only this experiment's resources:

```sh
make clean-homelab
```

## Evidence layout

`data/raw/{main,durability,serial}` contains JSONL summaries and one gzip-compressed CSV per measured trial. Main/serial event columns are application ID, publication invocation, publication confirmation, receive-request invocation, client receipt, consumer-acknowledgment completion, and worker. Times are integer Linux monotonic nanoseconds from the driver node. The durability files contain publication events only; their broker-side integrity check reconciles stored count, not all payload identities. `data/raw/recovery/summary.jsonl` records receipt, kill-call start, process-exit observation, redelivery, configuration, identity checks, and censoring. Pilot directories are not inputs to inference.

`data/environment` records hardware, exact image digests, effective server configuration, initial and resumed driver details, source revisions, retained error logs, and periodic cgroup/resource telemetry. The failed setup attempt remains in the original raw main summary. A later failed warm-up/cleanup is preserved in its original panic log and the deviation ledger, rather than reconstructed as a successful timing sample. `SHA256SUMS` covers delivered source, evidence, and final artifacts, excluding caches and LaTeX intermediates.

The delivered analyzer requires `data/environment/outcome-manifest.json` and the failure ledger, so a missing ledger cannot silently promote the diagnostic replay into a planned success. A new campaign needs its own manifest from its actual execution logs; it need not reproduce this failure.

The dataset is synthetic and local. The manuscript and software were developed with AI assistance. The artifact is not claimed to be publicly archived, externally artifact-evaluated, peer reviewed, or accepted by a journal. No external publication was performed.
