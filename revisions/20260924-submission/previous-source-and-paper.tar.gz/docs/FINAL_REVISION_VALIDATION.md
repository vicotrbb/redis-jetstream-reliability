# Final scientific revision and validation

Revision date: 24 September 2026. This is the current validation narrative. The current PDF and document-source identities are recorded in `data/derived/build-receipt.json`, `paper-check.json`, and `visual-review.json`. Earlier 25-page and 27-page receipts are explicitly historical; [ARTIFACT_MAP.md](ARTIFACT_MAP.md) identifies their archived documents and source snapshots.

The final revision preserves the title, author, section order, template, original evidence, primary estimates, mathematical results, and scientific scope. It resolves the actionable reporting, observation, and provenance issues identified in the second audit. It does not claim that missing historical observations were recovered or that disclosed design limitations were experimentally removed. The supported contribution remains a locally auditable, computationally reproducible descriptive study of the specified deployment and workloads.

## Disposition of all fourteen findings

| Audit finding | Final disposition | Verification or remaining limit |
|---|---|---|
| 1. Storage-history confounding | Retained prominently in methods, discussion, RQ3 interpretation, and threats. Original final AOF lengths and delayed-fsync counter remain unchanged. | No causal storage-reset experiment was added. Configured policy and evolving storage history remain entangled. |
| 2. D038 failed-trial missingness | Retained the planned failure, missing confirmation/timing data, and excluded completed replay. The new outcome inventory includes them as separate entries. | No snapshot count is imputed as confirmed throughput. Missing original client measurements remain irrecoverable. |
| 3. Bootstrap coverage and deployment dependence | Retained nominal, conditional intervals and the working IID block-resampling assumption, with existing influence and execution-order analyses. | No claim of demonstrated 95% coverage or independent-campaign precision. Independent replication remains necessary for broader inference. |
| 4. Sparse information behind publication p99 | Added the 59 per-trial message counts, nearest-rank indices, and higher order-statistic position counts. Added a six-profile table and explicit D040 interpretation to the paper. | Counts/ranks independently recomputed. D040 has 149 observations, p99 rank 148, and one higher position. The observation stays in the primary estimate. |
| 5. Untested storage durability and unequal contracts | Preserved separation of confirmation cost, consumer-state behavior, and the conditional storage proposition. | Consumer kills and latency measurements still do not establish power-loss survival or equal-guarantee efficiency. |
| 6. Operational setup/warm-up costs | Added an evidence-linked retrospective inventory of 556 records, plus a manuscript table distinguishing all 550 planned outcomes from six additional documented attempts. | Successful warm-ups belong to their completed attempts. Pilots and infrastructure provisioning are outside this inventory. Missing durations remain null. No full-stage availability or total-cost estimate is inferred. |
| 7. Narrow recovery workload | Retained one pending message, periodic profiles, survivor demand before failure, and absence of concurrent publication load beside the method and interpretation. | No large-PEL, saturated-load, or application-work generalization. |
| 8. Missing historical censor endpoints | Added an explicit historical measurement limitation and excluded exact censor-time or survival interpretation. Implemented distinct endpoints for future recovery observations. | Unit and real-broker checks validate current recording. Historical endpoints remain unavailable. A timer-notification observation is not an exact kernel timer-firing timestamp. |
| 9. Partial integrity construct | Retained the distinction between identifier/count reconciliation and complete payload preservation. | No full-payload readback or corruption-free-storage claim. |
| 10. Serial sensitivity confounding | Preserved differences in duration, count, concurrency, and storage history. | Serial results do not identify batching or prove equivalence. |
| 11. Platform/workload generalization | Preserved shared Btrfs/NVMe, compression, client, message, duration, and concurrency limitations. | No production SLA, saturation ceiling, or hardware-independent ranking. |
| 12. Bounded failure-capture validation | Kept the returned-error/caught-panic promise and its abrupt-driver-loss boundary. Existing memory-profile ambiguity checks still pass. | No network-loss, host-crash persistence, or universal failure-preservation guarantee. |
| 13. Stale validation references | Marked older receipts historical, redirected the README to this current record, archived the historical visual receipt, and introduced hash-bound build and document-QA gates. | Current source inputs, successful build, PDF, and retained rendered pages must agree. The old visual receipt is rejected. |
| 14. Local versus external reproducibility | Added the artifact version map and explicit limits on what hashes establish. The manuscript distinguishes computational reproduction from externally executed replication. | Public DOI, license selection, immutable public release, and external execution remain publication-stage actions, not claimed outcomes of this revision. |

## Preserved scientific evidence

The initial state of this pass matched all **816** checksums supplied to the second audit. That inventory is retained in `revisions/20260924-final/baseline-manifest.json` and `baseline-SHA256SUMS`. The previous source, PDF, and QA are archived in `previous-revision-source-and-paper.tar.gz`.

All **537 original raw-data and environment files** remain byte-identical to the frozen original evidence lock. Full raw-event analysis passed again for **419 completed primary timing trials and 17,411,288 message records**. The 120 active recovery outcomes and ten controls retain their original interpretation. The primary `statistics.json`, all 420 aggregate CSV rows, the original result tables, all four primary figures, and the Lean source are byte-identical to the previously audited revision. All thirteen paired primary effects therefore retain their original estimates and intervals.

The new publication-tail records describe existing observations. Their count, selected rank, upper-position count, profile, and p99 value are checked independently against the retained summaries, whose values are reconstructed from raw events by the main analyzer. The new outcome inventory links original rows or documented incidents to their source files and lines, records source hashes, and marks unavailable times and counts as missing. It is a retrospective inventory, not new experimental data or a prospective exclusion rule.

## Recovery instrumentation and homelab execution

The final functional validation used campaign `final20260924`, attempt `a001`, exclusively through `kubectl --context homelab` in namespace `msgrel-final20260924-a001`. Its successful run, sealed inputs, collection, and environment receipts are retained under `campaigns/final20260924/attempts/a001/`. Current driver and collection sources match the validated input snapshot.

- Five Go regression tests passed with the race detector. They cover publication-error preservation, caught worker panic, identity/destination protection, waiting for an outstanding operation after the censor budget, retaining a late returned receipt, and success without an invented timer-expiry timestamp. One test contains two subcases.
- Nine Python campaign-isolation tests passed in the same homelab runner.
- Nine real broker scenarios passed: two memory-profile drains, two successful memory-profile publication runs, two ambiguous-confirmation injections, two active periodic-profile recoveries, and one Redis periodic no-reclaimer control.

Future records distinguish `censor_budget_start_ns`, `nominal_censor_deadline_ns`, `timer_notification_observed_ns`, `survivor_loop_completed_ns`, `controller_wait_completed_ns`, `reconciliation_start_ns`, and `reconciliation_end_ns`. The timer observation is null for recovery before its branch is taken. Loop completion is timestamped immediately before sending the terminal result. A receipt returned during shutdown is recorded explicitly, rather than silently being treated as an empty observation.

The real control retained pending state after the outstanding read returned, with the observed completion later than its 500 ms nominal budget. This confirms the purpose of separating the endpoints; it is a functional check, not a new performance sample. It does not establish a hard response-time bound or crash-persistent recording.

The final driver was built with Go 1.24.4 for Linux/amd64. Binary SHA-256: `fcd1a414857d0e0338c6b35402d9b50375ecd11a47656e2ba2dac981cd7a5da2`. The binary receipt is `revisions/20260924-final/driver-binary-receipt.json`. Validation evidence was collected before namespace deletion. `revisions/20260924-final/cleanup.json` records successful cleanup and a subsequent absence check. Original namespaces and unrelated resources were not changed by this pass.

## Formal and source grounding

The hand arguments and their stated domains were reread against the manuscript's claim boundaries. The new p99-rank discussion follows directly from the already defined nearest-rank statistic. It introduces no population-tail theorem or additional independence claim.

The selected Lean model was not changed. Both retained successful receipts match its current source digest and the same ten declarations. The latest compiler invocation was the prior revision's separate homelab check on 24 September; this final pass verifies those receipts and source identity rather than claiming another compiler execution. The source and literature checks recorded in [SOURCE_REVALIDATION.md](SOURCE_REVALIDATION.md), together with the supplied second audit, remain the foundation for the unchanged version-specific implementation claims. No new broker semantics or bibliographic claims were introduced.

## Build, document, and provenance verification

The final manuscript has **29 pages and 31 cited references**, preserving the original template and section order. All pages are rendered, and the visual-review receipt records exactly which renderings were inspected. The new tables and discussion, mathematical notation, conclusion, appendix transitions, and bibliography receive additional full-page inspection. The Appendix C heading is kept with its claim-to-evidence table. Source and extracted PDF text contain no em dashes; fonts are embedded, with no unresolved references or overfull boxes.

During document production, a caption containing a file-path macro caused a LaTeX build failure. Moving the path into the body resolved the formatting error. This also exposed an artifact-gate weakness: the old content check could inspect the previous PDF after a failed build. That gate is now strengthened. `bench/build_paper.py` records a successful compiler exit, exact source-input hashes, output PDF hash, page count, and compiler-log hash. `bench/check_paper.py` verifies that binding and rejects failed-build diagnostics. `bench/check_document_provenance.py` additionally requires matching current visual QA and retained page-render hashes and explicitly rejects the old receipt.

Current receipts are `data/derived/build-receipt.json`, `paper-check.json`, and `visual-review.json`, plus `revisions/20260924-final/revision-check.json` and `document-provenance-check.json`. `SHA256SUMS` is regenerated only after document inspection and final report completion. A subsequent source or PDF change requires the relevant checks and visual review again; updating a manifest alone cannot substitute for them.

## Final scope

The local scientific revision is complete at its stated scope, and the accompanying current checks pass. The paper reports observations, conditional proofs, documented missingness, and unverified assumptions distinctly. No absolute perfection, peer-review acceptance, independent replication, tested storage durability, or broader population claim is asserted. No public deposit, license grant, or journal submission was performed. Those actions remain separate from the completed manuscript revision.
