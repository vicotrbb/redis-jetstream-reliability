# Artifact versions and reproduction scope

The project has no Git history. Its retained source snapshots, archives, input seals, and manifests identify the versions below. A content hash establishes byte identity within this package, not independent certification of collection time or completeness before sealing.

| Artifact | Role and identity |
|---|---|
| `data/raw/` and `data/environment/` | Frozen original campaign `msgrel-20260923`. All 537 files are bound by `revisions/20260924/original-evidence-lock.json`. No later validation observations are added here. |
| `data/environment/harness-v1/` through `harness-v4/` | Historical measured implementations and continuation changes. `docs/DEVIATIONS.md`, driver build receipts, and execution logs identify their use. Earlier snapshots are part of the frozen evidence. |
| `revisions/20260924/original-source-and-paper.tar.gz` | Source and document archive from before the first scientific revision. Includes the original measured implementation and the 25-page PDF with hash `386e1c56f5aad3cf3a054daf1043225e7af738139350fdb1fb8d2be55f084472`. |
| `campaigns/rev20260924/attempts/a004/inputs/` | Sealed first-revision harness: publication-error capture and campaign isolation. Its separate functional collection and run result identify successful validation. It did not generate the original performance data. |
| `revisions/20260924-final/previous-revision-source-and-paper.tar.gz` | Previous audited revision, including the 27-page PDF with hash `458f1f005872ddb807a9273315b65c28132f2b888889388b6288abf8d56ee555`, its source, and historical QA. The adjacent baseline inventory identifies all 816 files in that delivery. |
| `campaigns/final20260924/attempts/a001/inputs/` | Sealed final recovery-controller source and functional-validation input. Adds separate observation endpoints and retention of a receipt returned during shutdown. Its collection is functional evidence only. |
| `bench/`, `paper/`, `data/derived/`, `output/pdf/` | Current collection source, analysis, manuscript, generated results, and reader-facing document. Current `SHA256SUMS` identifies them. No assertion is made that current `bench/` was used for historical observations. |
| `formal/DeliveryModel.lean` | Unchanged selected abstract model. `formal/verification.json` identifies the original successful compile; `revisions/20260924/lean-recheck.json` identifies the independent later invocation on the homelab. Neither verifies broker implementations. |
| `data/derived/visual-review.json` | Current PDF hash, source inputs, retained rendered-page hashes, and review scope. `bench/check_document_provenance.py` rejects a receipt for a different PDF or source snapshot. |
| `data/derived/build-receipt.json` | Successful compiler exit and exact input, PDF, and compiler-log hashes. The paper checker rejects stale outputs after failed builds or later source changes. |
| `docs/EXECUTION_RECEIPT.md`, `docs/REVISION_VALIDATION.md` | Explicitly historical validation narratives. The current narrative is `docs/FINAL_REVISION_VALIDATION.md`. |

## Reanalysis versus new experiments

Reanalyze retained data with the pinned Python dependencies and `make analyze`. Build the manuscript with `make paper`, render and inspect that exact output, and then use `make verify-revision`. Regenerate `SHA256SUMS` only after all source, evidence, and review records are finalized. A changed PDF requires new document QA; changing a checksum file cannot substitute for inspection.

New broker execution is permitted only through `kubectl --context homelab`. It requires new campaign and attempt identifiers and its own adjudication and analysis. Original D038 and D043 client traces and exact historical control endpoints remain unavailable. Existing evidence must not be rewritten to imply that later instrumentation was present during collection.

## Archival release boundary

The local artifact has not been publicly deposited, externally executed, or externally artifact-evaluated. No DOI or acceptance is asserted. Before a public release, the author must select the manuscript/data and software licenses and confirm the release metadata. This revision does not grant new publication or redistribution rights on the author's behalf. Third-party dependencies retain their own licenses.

A release should include source, raw and derived data, pinned dependencies, original and revised harness maps, formal receipts, current document QA, and content manifests, with caches and build intermediates excluded. The chosen release must be immutable and its identifier added to the manuscript only after assignment. These publication actions are separate from completing and validating the local scientific revision.
